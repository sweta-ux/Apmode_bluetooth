#include "hardware.h"
#include "cloud.h"
#include "nv.h"
#include "server_response.h"
#include <MQTT.h>
#include <ArduinoJson.h>
#include <iotmqtt.h>
#include <Arduino.h>

/* Extern MQTTClient object */
extern MQTTClient mqttClient;

/* Extern iotmqtt object */
extern iotmqtt *mqtt;

/* initialise gpio's according to the NUM_RELAYS */
#ifdef WIFISTRIP_PINS
int relaygpios[NUM_RELAYS] = {R1, R2, R3, USB};
#endif

#ifdef WIFIMINI_PINS
int relaygpios[NUM_RELAYS] = {R1, R2, R3, R4};
#endif

#if defined (WIFIMINI_8_RELAY_PINS) || defined (WIFIPLATE_PINS)
int relaygpios[NUM_RELAYS] = {R1, R2, R3, R4,R5, R6};
#endif

#ifdef WIFIPLUG_PINS
int relaygpios[NUM_RELAYS] = {R1};
#endif

/* defining global variables */
bool interrupt_flag = false;
String random_string;
int cmd;
int weather_info = 0;  //weather flag bug

/* extern structures */
extern struct relay_def *relay;
extern struct cloud_def _config;
struct temp_weather_def _weather;

/* extern avg_wattage of power */
extern float avg_wattage;

/**
 * received_message-> creating a task for receving msg from the cloud 
 * args: void *pvParameters
 * returns: void
 */
void receive_from_server(void *pvParameters) {
  PRINTS("RECEIVE_FROM_SERVER running on core ");
  PRINTR(xPortGetCoreID());
  for(;;) {
    TIMERG0.wdt_wprotect = TIMG_WDT_WKEY_VALUE;
    TIMERG0.wdt_feed=1;
    TIMERG0.wdt_wprotect=0;
    mqttClient.onMessage(message_received);
  }
  DELAY_100;
}

/**
 * message_received - function fore receving the message from the mqtt
 *                    and check the cmd
 * args: string topic, string payload
 * return: void
 */
void message_received(String &topic, String &payload) {
  PRINTR("incoming: " + topic + " - " + payload);
  //DynamicJsonBuffer jsonBuffer(1500);
  StaticJsonBuffer<2000> jsonBuffer;
  JsonObject& root = jsonBuffer.parseObject(payload);
  if (!root.success()) {
    PRINTR("invalid json");
    show_notification(invalid_json, 1);
  }

  /* parsing key_values from incomming json */
  int cloud_ver  = root["version"];
  cmd = root["cmd"];
  String url = root["url"];
  random_string = (const char*)root["commandId"];
  String peripherals = root["peripheral"];
  String weather = root["weather"];
  String action = root["action"];
  bool online = true;
  bool debug = root["debug"];
  check_cmd(cmd, peripherals, url, weather, action, cloud_ver, debug, online);
}

/**
 * parse_cmd-: updating relays according to the command
 * args: void
 * ret: void
 **/
void check_cmd(int cmd, String peripherals, String url, String meta, String action, int version, bool debug, bool online) {
  switch(cmd) {
    case 1: /* request for OTA */
      update_firmware(url);
      break;
    case 2: { /* request for Toggling relays */
      if (version == code_version) {    /* check cloud_version and code_version if version matched then proceed the cmd */
        DynamicJsonBuffer jsonBuffer(300);
        JsonObject& device = jsonBuffer.parseObject(peripherals);
        if (!device.success()) {
          PRINTR("invalid json");
          show_notification(invalid_json, 1); 
        }
        for (int i = 1; i<= NUM_RELAYS; i++) {
          String relay_id;
          relay_id = "r" + String(i);
          #ifdef WIFISTRIP
          if (i == 4) {
            relay_id = "usb";
          } else {
            relay_id = "r" + String(i);
          }
          #endif

          /* check if json contain relay_id key value */
          bool r = device.containsKey(relay_id);
          if (r) {
            relay[i].state = device[relay_id]["state"];
            relay[i].flag = true;
            toggle_relay(i);
          } else {
            relay[i].flag = false;
          }
        }
        if (online) {
          generate_interrupt();
        }
      }
      break;
    }
    case 4: { /* request for device status */
      if (version == code_version) { /* check cloud_version and code_version if version matched then proceed the cmd */
        String data = check_per_int(false);
        publish_on_response(data);
        PRINTR(data);
        PRINTR("check cmd 4");   //adding
      }
      break;
    }
    case 5: {
      /* request for weather information */
      if (version == code_version) { /* check cloud_version and code_version if version matched then proceed the cmd */
        DynamicJsonBuffer jsonBuffer(300);
        //StaticJsonBuffer<300> jsonBuffer;
        JsonObject& meta_data = jsonBuffer.parseObject(meta);
        String weather_data = meta_data["weather"];
        JsonObject& weather_info = jsonBuffer.parseObject(weather_data);
        if (!weather_info.success()) {
          PRINTR("invalid json");
          show_notification(invalid_json, 1); 
        }
        const char* temp = weather_info["temp"];
        const char* temp_min = weather_info["temp_min"];
        const char* temp_max = weather_info["temp_max"];
        const char* desc = weather_info["description"];
        const char* icon = weather_info["icon"];
        check_temp_weather (temp, temp_min, temp_max, desc, icon, &_weather);
      }
      break;
    }
    case 6: {
      if (version == code_version) { /* check cloud_version and code_version if version matched then proceed the cmd */
        String delete_info = delete_response(6);
        publish_on_delete(delete_info);
        clear_nv();
        DELAY_100;
        ESP.restart();
      }
    }
    case 7: {
      if ((version == code_version) && (debug)) { /* check cloud_version and code_version */
        Serial.begin(115200);
      }
    }
    default:
      /* ERROR */
      break;
  }
}

/**
 * check_temp_weather:- checking weather and temp data
 * ret:- void 
 * args:- void
 **/
void check_temp_weather (const char* temp, const char* temp_min, const char* temp_max, const char* desc, const char* icon, struct temp_weather_def *_weather) {
  String tempT = temp;
  int splitDot = tempT.indexOf(".");
  _weather->temp_Str = tempT.substring(0,splitDot);
  String tempMin = temp_min;
  int splitDot_Min = tempMin.indexOf(".");
  _weather->temp_minStr = tempMin.substring(0,splitDot_Min);
  String tempMax = temp_max;
  int splitDot_Max = tempMax.indexOf(".");
  _weather->temp_maxStr = tempMax.substring(0,splitDot_Max);
  _weather->desc = desc;
  PRINTR(_weather->desc);
  _weather->icon = icon;
  PRINTR(_weather->icon);
}

/**
 * generate_interrupt - generating interupt using GPIO pin
 * args: void
 * ret: void 
 */
void generate_interrupt() {
  digitalWrite(JSON_INTERRUPT, LOW);
  DELAY_100;
  digitalWrite(JSON_INTERRUPT, HIGH);
  DELAY_100;
}

/**
 * toggle_relay:- toggle relays
 * args: void
 * ret: vpid 
 */
void toggle_relay(int i) {
  digitalWrite(relaygpios[i-1], relay[i].state);
}

/**
 * send_to_server_periodically - creating the task for publish json
 * args: void *pvparameters
 * return: void
 */
void send_to_server_periodically(void *pvParameters) {
  PRINTS("SEND_TO_SERVER running on core");
  PRINTR(xPortGetCoreID());
  for(;;){
    TIMERG0.wdt_wprotect = TIMG_WDT_WKEY_VALUE;
    TIMERG0.wdt_feed=1;
    TIMERG0.wdt_wprotect=0;
    periodic_response_send(false);
  }
  DELAY_100;
}



/**
 * periodic_response_send - publish the json periodically
 * args: void
 * return: void
 */
unsigned long lastMillis = 0;
void periodic_response_send(bool manual_switch) {
  unsigned long currentmillis = millis();
  if (((currentmillis) - (lastMillis) > (max_sending_time)) || (interrupt_flag) || (manual_switch)) {
    if ((interrupt_flag)) { /* if interrupt generate send response to cloud */
      String data = check_per_int(manual_switch);
      publish_on_response(data);
      PRINTR(data);
      data = "\0";
      PRINTR("interrupt generate");
    } else { /* send periodic data to cloud */
      String data = check_per_int(manual_switch);
      publish_on_periodic(data);
      PRINTR(data);
      PRINTR("periodic");
      data = "\0";
      if (!manual_switch) {
        weather_info++;
        lastMillis = currentmillis;
        currentmillis = 0;
        avg_wattage = 0;
      }
      cmd = 0;
    }
  }
  if (weather_info == 240) { /* when weather_info is 240 send device_info to cloud */
    String weather_api = device_info();
    publish_state(weather_api);
    Serial.println(weather_api);
    weather_info = 0;
  }
}

/**
 * publish_json_on_telemetry - publish json string when recieve interrupt_flag as true
 * args: void
 * return: void
 */
String check_per_int(bool manual_switch) {
  String response;
  if (interrupt_flag) {
    response = relays_response(false, cmd, manual_switch);
    interrupt_flag = false;
  } else {
    response = relays_response(true, cmd, manual_switch);
  }
  return response;
}

/**
 *publish_Telemetry-> method for sending data
 * args: String data
 * returns: bool
 */
bool publish_telemetry(String data) {
  bool xyz = mqtt->publishTelemetry(data);
  return xyz;
}

/**
 *publish_on_subtopic -> method for sending data on response subtopics
 * args: String subtopic & string data
 * returns: bool
 */
bool publish_on_response(String data) {
  bool send_data = mqtt->publishonsubtopic("/response", data);
  return send_data;
}

/**
 *publish_on_subtopic -> method for sending data on periodic subtopics
 * args: String subtopic & string data
 * returns: bool
 */
bool publish_on_periodic(String data) {
  bool send_data = mqtt->publishonsubtopic("/periodic", data);
  return send_data;
}

/**
 *publish_on_subtopic -> method for sending data on periodic subtopics
 * args: String subtopic & string data
 * returns: bool
 */
bool publish_on_delete(String data) {
  bool send_data = mqtt->publishonsubtopic("/deletedevice", data);
  return send_data;
}

/**
 * relays_response:- response of every relays separatly
 * args:- void
 * ret:- void
 */
String relays_response(bool is_periodic, int cmd, bool manual_switch) {
  DynamicJsonBuffer jsonBuffer(300);
  JsonObject& periodic_json = jsonBuffer.createObject();
  periodic_json["device_id"] = _config.cloud_device_id;
  periodic_json["timestamp"] = String(time(nullptr));
  periodic_json["version"] = String(code_version);
  String ip_addr = check_ip();
  periodic_json["ip_address"] = ip_addr;
  if (!is_periodic) {
    if (random_string == NULL) {
      periodic_json["status"] = String(3);
      periodic_json["commandId"] = "";
    } else {
      periodic_json["status"] = String(cmd);
      periodic_json["commandId"] = random_string;
    }
    JsonObject& peripherals =  periodic_json.createNestedObject("peripherals");
    for (int i = 1; i <= NUM_RELAYS; i++) {
      String relay_id;
      relay_id = "r" + String(i);
      #ifdef WIFISTRIP
      if (i == 4) {
        relay_id = "usb";
      } else {
        relay_id = "r" + String(i);
      }
      #endif
      if (relay[i].flag) {
        //JsonObject& per = peripherals.createNestedObject(relay_id);
        //per["name"] = relay[i].name;
        peripherals[relay_id + "/state"] = String(relay[i].state);
        relay[i].flag = false;
      }
    }
  } else {
    if (cmd == 4) {
      periodic_json["status"] = String(cmd);
      if (random_string == NULL)
        periodic_json["commandId"] = "";
      else
        periodic_json["commandId"] = random_string;
    } else {
      periodic_json["status"] = "3";
      periodic_json["commandId"] = "";
      periodic_json["code_sha"] = code_sha;
    }
    
    JsonObject& peripherals = periodic_json.createNestedObject("peripherals");
    for (int i = 1; i <= NUM_RELAYS; i++) {
      String relay_id;
      relay_id = "r" + String(i);
      #ifdef WIFISTRIP
      if (i == 4) {
        relay_id = "usb";
      } else {
        relay_id = "r" + String(i);
      }
      #endif

      #ifdef WIFIPLUG
      relay_id = "r" + String(i);
      #endif
      peripherals[relay_id + "/state"] = String(relay[i].state);
    }
    if(!manual_switch) {
      #ifdef POWER_MEASUREMENT
      JsonObject& power = peripherals.createNestedObject("power");
      power["power"] = String(avg_wattage);
      #endif
    }
  }
  String response;
  periodic_json.printTo(response);
  random_string = "";
  return response;
}

/**
 * delete_response:- response of delete action
 * args:- void
 * ret:- void
 */
String delete_response(int cmd) {
  DynamicJsonBuffer jsonBuffer(300);
  JsonObject& delete_json = jsonBuffer.createObject();
  delete_json["device_id"] = _config.cloud_device_id;
  delete_json["status"] = cmd;
  delete_json["version"] = String(code_version);
  delete_json["action"] = "hardreset";
  String response;
  delete_json.printTo(response);
  return response;
}

/**
 * send_json - changing the interrupt_flag in bool
 * args: void
 * return: void
 */
void send_json() {
  interrupt_flag = true;
}