#include "apmode.h"

char device_ssid[30];

IPAddress local_ip(192, 168, 1, 1);
IPAddress gateway(192, 168, 1, 1);
IPAddress subnet(255, 255, 255, 0);

int str_len;
  
/**
 * ap_mode - enable ap_mode when SSID/Pass is not available
 * args: void
 * return: void
 */
void enter_ap_mode() {
  char *ap_did = device_name();
  WiFi.softAP(ap_did);
   WiFi.disconnect();
  if (WiFi.isConnected())
    PRINTR("Wifi is connected");
  //clear_nv();
  WiFi.softAPConfig(local_ip, gateway, subnet);
  if((WiFi.status() != WL_CONNECTED)) {
    local_server();
  }
}

/**
 * mac_aadress:- fetching mac address of esp32
 * args: void
 * ret: String
 */
String mac_address(void) {
  String newmac = WiFi.macAddress();
  return newmac;
}

/**
 * six_digit_mac:- fetching 6 digit of mac address of from an array
 * args: void
 * ret: String
 */
String  six_digit_mac(void) {
  String mac = mac_address();
  str_len = mac.length() + 1;
  char mac_add[str_len];
  mac.toCharArray(mac_add, str_len);
  char mac1 = mac_add[9];
  char mac2 = mac_add[10];
  char mac4 = mac_add[12];
  char mac5 = mac_add[13];
  char mac7 = mac_add[15];
  char mac8 = mac_add[16];
  String add = String(mac1)+String(mac2)+String(mac4)+String(mac5)+String(mac7)+String(mac8);
  return add;
}

/**
 * device_name:- fetching mac address of from an array
 * args: void
 * ret: char *
 */
char *device_name(void) {
  String mac = six_digit_mac();
  String ap_mode_name = ap_mode + mac;
  ap_mode_name.toCharArray(device_ssid, str_len);
  return device_ssid;
}