#include "WiFi.h"
#include "ble.h"
#include <ArduinoJson.h>
#include "definitions.h"
#include "hardware.h"
#include "nv.h"
#include "server_response.h"
#include "apmode.h"
#include "oled.h"
#include "BluetoothSerial.h" //Header File for Serial Bluetooth, will be added by default into Arduino
BluetoothSerial ESP_BT; //Object for Bluetooth

char ble_device_ssid[30];
bool connected;

/**
 * mac_aadress:- fetching mac address of esp32
 * args: void
 * ret: String
*/
void init_ble(void) {
  WiFi.mode(WIFI_OFF);
  char *ble_id = device_name();
  ESP_BT.begin(ble_id);
  PRINTR("in ble");
  receive_message_from_ble();
}

void receive_message_from_ble() {
  while (WiFi.status() != WL_CONNECTED) {
    show_notification(server_mode, 3);
    if (ESP_BT.available()) {//Check if we receive anything from Bluetooth
      String ble_json = ESP_BT.readString(); //Read what we recevive
      bool stop_flag = false;
      if (ble_json != "NULL") {
        //message += String(ble_json);
        PRINTR("Received:");
        PRINTR(ble_json);
        stop_flag = true;
      }
      if (stop_flag){
        const char *server_data = ble_json.c_str();
        nv_write(SPIFFS, data_file, server_data);
        ESP_BT.end();
        break;
      }
    }
  }
  DELAY_200;
 }