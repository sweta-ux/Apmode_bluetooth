#include <time.h>
#include "SSD1306.h"
#include "definitions.h"
#include "ntp.h"

const char* NTP_SERVER = "0.pool.ntp.org";
const char* TZ_INFO    = "IST-5:30";

tm *localTime;
tm timeinfo;
time_t now;

char time_output[30];
char date_output[30];
char day_output[30];

/**
 * init_ntp - initialised NTP server
 * args: void
 * ret: int
 */
int init_ntp(void) {
  #ifdef NTP
  configTime(0, 0, NTP_SERVER); 
  setenv("TZ", TZ_INFO, 1);
  return set_ntp_time(10, &timeinfo);
  #endif
}

/**
 * set_ntp_time - setting ntp time with millis
 * args: int sec
 * ret: int
 */
int set_ntp_time(int sec, tm *localTime) {
  uint32_t start = millis();
  do {
    time(&now);
    localtime_r(&now, &timeinfo);
  } while (((millis() - start) <= (1000 * sec)) && (timeinfo.tm_year < (2020 - 1900)));

  if (timeinfo.tm_year <= (2016 - 1900)) {
    // the NTP call was not successful
    return FAILURE;
  }
}

/**
* ntp_time - getting ntp time from ntp server
* args: void
* ret: char
*/
char *ntp_time(void) {
  #ifdef NTP
  set_ntp_time(10, &timeinfo);
  return time_output;
  #endif
}

/**
 * ntp_day - getting day from ntp server
 * args: void
 * ret: char
 */
char *ntp_day(void) {
  #ifdef NTP
  set_ntp_time(10, &timeinfo);
  return day_output;
  #endif
}

/**
 * ntp_date - getting date from ntp server
 * args: void
 * ret: char
 */
char *ntp_date(void) {
  #ifdef NTP
  set_ntp_time(10, &timeinfo);
  return date_output;
  #endif
}