#include "Update.h"
#include "HTTPClient.h"
#include "ota.h"
#include "server_response.h"
#include "definitions.h"

extern struct relay_def relay;

HTTPClient http;
/**
 * update_firmware:- hit the http request for fetching the new firmware
 * args:- String
 * ret:- void
 */
void update_firmware(String url) {
  http.begin(url);
  int httpCode = http.GET();
  PRINTR("httpcode is:");
  PRINTS(httpCode);
  if (httpCode <= 0) {
    http.errorToString(httpCode).c_str();
    return;
  }
  // Check that we have enough space for the new binary.
  PRINTR("checking size of the file");
  http.getSize();
  int contentLen = http.getSize();
  Serial.printf("Content-Length: %d\n", contentLen);
  bool canBegin = Update.begin(contentLen);
  if (!canBegin) {
    PRINTR("Not enough space to begin OTA");
    return;
  }
  // Write the HTTP stream to the Update library.
  WiFiClient* client = http.getStreamPtr();  
  size_t written = Update.writeStream(*client);
  Serial.printf("OTA: %d/%d bytes written.\n", written, contentLen);
  PRINTR(written);
  if (written != contentLen) {
    PRINTR("Wrote partial binary. Giving up.");
    return;
  }
  if (!Update.end()) {
    PRINTR("Error from Update.end(): " + 
    String(Update.getError()));
    return;
  }
  if (Update.isFinished()) {
    PRINTR("Update successfully completed. Rebooting."); 
    // This line is specific to the ESP32 platform:
    ESP.restart();
  } else {
    PRINTR("Error from Update.isFinished(): " + 
    String(Update.getError()));
    return;
  }
}